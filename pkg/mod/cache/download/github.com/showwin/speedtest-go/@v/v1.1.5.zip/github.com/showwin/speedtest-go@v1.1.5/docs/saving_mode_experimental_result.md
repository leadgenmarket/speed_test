# --saving-mode Experimental Result

`--saving-mode` vs normal mode.

`N - Download` means normal mode download speed results.  
`S - RAM` means `--saving-mode` memory usage.

| exp No. | N - Download | N - Upload | N - RAM | S - Download | S - Upload | S- RAM |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: |
| 1 | 54.13 Mbit/s | 61.07 Mbit/s | 85.82MB | 50.65 Mbit/s | 29.25 Mbit/s | 5.39MB |
| 2 | 47.65 Mbit/s | 57.94 Mbit/s | 93.84MB | 48.39 Mbit/s | 44.04 Mbit/s | 9.39MB |
| 3 | 52.58 Mbit/s | 56.43 Mbit/s | 109.86MB | 24.34 Mbit/s | 41.68 Mbit/s | 9.39MB |
| 4 | 43.73 Mbit/s | 49.46 Mbit/s | 109.86MB | 32.10 Mbit/s | 36.51 Mbit/s | 9.39MB |
| 5 | 54.66 Mbit/s | 42.81 Mbit/s | 101.84MB | 40.08 Mbit/s | 10.37 Mbit/s | 5.39MB |
